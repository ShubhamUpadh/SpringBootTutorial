package com.Prac5.SpringSecurityExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Prac5Application {

	public static void main(String[] args) {
		SpringApplication.run(Prac5Application.class, args);
	}

}
