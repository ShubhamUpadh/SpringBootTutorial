package com.Prac5.SpringSecurityExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prac5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
