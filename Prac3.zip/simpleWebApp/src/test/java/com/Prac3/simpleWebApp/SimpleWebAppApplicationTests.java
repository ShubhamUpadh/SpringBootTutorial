package com.Prac3.simpleWebApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
